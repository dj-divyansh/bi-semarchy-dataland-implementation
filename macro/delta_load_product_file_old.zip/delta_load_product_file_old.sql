{#
    MACRO: delta_load_product_file_v2
    ============================================================
    Purpose:
        Performs a Data Vault 2.0 delta/CDC load for Veeva CRM product data.
        Reads from the staging view (stg_veeva_crm_product_all_v2) and applies
        changes to the HUB, SAT, and HIST tables using MD5 hash comparison.
 
    Delta Logic Overview:
        1. UNCHANGED records (identifier_md5 match AND record_md5 match):
           -> Only update UPDATED_DATETIME on the active SAT record.
           -> Then exclude these from further processing via a temp delta table.
 
        2. CHANGED records (identifier_md5 match BUT record_md5 mismatch):
           -> Archive the old SAT record to SAT_PRODUCT_HIST with END_DATETIME.
           -> Delete the old record from SAT_PRODUCT_FILE.
           -> Insert the new version into SAT_PRODUCT_FILE with START_DATETIME.
 
        3. NEW records (no identifier_md5 match in HUB):
           -> Insert into HUB_PRODUCT_FILE with LOAD_DATETIME.
           -> Insert into SAT_PRODUCT_FILE with START_DATETIME.
 
    Filtering:
        Records with NULL or empty GEOGRAPHIC_ID, PRODUCT_NAME, or
        DATASET_PRODUCT_ID are excluded from all processing.
 
    Tables Involved:
        - Source: stg_veeva_crm_product_all_v2 (dbt staging view)
        - Hub:    DEV_DFHPMS2EU_DB.DW_DFHPMS2EU_SEMARCHY_SCHEMA.HUB_PRODUCT_FILE
        - Sat:    DEV_DFHPMS2EU_DB.DW_DFHPMS2EU_SEMARCHY_SCHEMA.SAT_PRODUCT_FILE
        - Hist:   DEV_DFHPMS2EU_DB.DW_DFHPMS2EU_SEMARCHY_SCHEMA.SAT_PRODUCT_HIST
 
    Usage:
        dbt run-operation delta_load_product_file_v2
#}
{% macro delta_load_product_file_v2() %}
 
    {# -- Target table references -- #}
    {% set hub_table = 'DEV_DFHPMS2EU_DB.DW_DFHPMS2EU_SEMARCHY_SCHEMA.HUB_PRODUCT_FILE' %}
    {% set sat_table = 'DEV_DFHPMS2EU_DB.DW_DFHPMS2EU_SEMARCHY_SCHEMA.SAT_PRODUCT_FILE' %}
    {% set hist_table = 'DEV_DFHPMS2EU_DB.DW_DFHPMS2EU_SEMARCHY_SCHEMA.SAT_PRODUCT_HIST' %}
    {% set stg_table = ref('stg_veeva_crm_product_all_v2') %}
 
    {# ------------------------------------------------------------------
       STEP 1a: Build a filtered delta staging table.
       Excludes records where BOTH identifier_md5 and record_md5 already
       match an active SAT row (i.e. unchanged records). Also applies
       the data quality filter (non-null geographic_id, product_name,
       dataset_product_id). The resulting temp table is used by all
       subsequent steps so they only process true deltas.
    ------------------------------------------------------------------ #}
    {% set create_filtered_stg_sql %}
        CREATE OR REPLACE TEMPORARY TABLE DEV_DFHPMS2EU_DB.DW_DFHPMS2EU_SEMARCHY_SCHEMA.TMP_STG_PRODUCT_DELTA AS
        SELECT stg.*
        FROM {{ stg_table }} stg
        WHERE stg.GEOGRAPHIC_ID IS NOT NULL AND TRIM(stg.GEOGRAPHIC_ID) != ''
          AND stg.PRODUCT_NAME IS NOT NULL AND TRIM(stg.PRODUCT_NAME) != ''
          AND stg.DATASET_PRODUCT_ID IS NOT NULL AND TRIM(stg.DATASET_PRODUCT_ID) != ''
          AND NOT EXISTS (
              SELECT 1
              FROM {{ sat_table }} sat
              WHERE sat.IDENTIFIER_MD5 = stg.IDENTIFIER_MD5
                AND sat.RECORD_MD5 = stg.RECORD_MD5
                AND sat.END_DATETIME IS NULL
          )
    {% endset %}
 
    {% set filtered_stg = 'DEV_DFHPMS2EU_DB.DW_DFHPMS2EU_SEMARCHY_SCHEMA.TMP_STG_PRODUCT_DELTA' %}
 
    {# ------------------------------------------------------------------
       STEP 1: Touch unchanged records.
       When both identifier_md5 AND record_md5 match between staging and
       the active SAT row, the data has not changed. We only refresh
       UPDATED_DATETIME to record that the source still provides this
       record. No new SAT row is created.
    ------------------------------------------------------------------ #}
    {% set update_unchanged_sql %}
        UPDATE {{ sat_table }} sat
        SET sat.UPDATED_DATETIME = CURRENT_TIMESTAMP()
        WHERE sat.END_DATETIME IS NULL
          AND EXISTS (
              SELECT 1
              FROM {{ stg_table }} stg
              WHERE stg.GEOGRAPHIC_ID IS NOT NULL AND TRIM(stg.GEOGRAPHIC_ID) != ''
                AND stg.PRODUCT_NAME IS NOT NULL AND TRIM(stg.PRODUCT_NAME) != ''
                AND stg.DATASET_PRODUCT_ID IS NOT NULL AND TRIM(stg.DATASET_PRODUCT_ID) != ''
                AND stg.IDENTIFIER_MD5 = sat.IDENTIFIER_MD5
                AND stg.RECORD_MD5 = sat.RECORD_MD5
          )
    {% endset %}
 
    {# ------------------------------------------------------------------
       STEP 2: Archive changed records to history.
       When identifier_md5 matches (same business key) but record_md5
       differs (attributes changed), copy the old active SAT row into
       SAT_PRODUCT_HIST and stamp END_DATETIME = now. This preserves
       the previous version of the record for audit/history.
    ------------------------------------------------------------------ #}
    {% set archive_changed_sql %}
        INSERT INTO {{ hist_table }} (
            IDENTIFIER_MD5, RECORD_MD5, LOAD_DATETIME, ETL_BATCH_ID, RECORD_SOURCE,
            GEOGRAPHIC_ID, DATASET_ID, SOURCE_DATASET_ID, DATASET_PRODUCT_ID,
            PRODUCT_TYPE_CODE, PRODUCT_NAME, STANDARDIZED_PRODUCT_NAME, DESCRIPTION,
            PRODUCT_STATUS_CODE, EFFECTIVE_DATE, END_DATE, BRAND_NAME, GENERIC_NAMES,
            APPROVED_DATE, MARKETING_START_DATE, MARKETING_END_DATE, EXPIRATION_DATE,
            SUBSTANCE, DOSE_FORM_CODE, STRENGTH, ROUTE_OF_ADMINISTRATION_CODE,
            PHARMACEUTICAL_PRODUCT_QUANTITY, UNIT_OF_PRESENTATION_CODE,
            PRIMARY_PACKAGE_QUANTITY, PRIMARY_PACKAGE_TYPE_CODE,
            SECONDARY_PACKAGE_QUANTITY, SECONDARY_PACKAGE_TYPE_CODE,
            PACKAGE_QUANTITY, SHELF_LIFE_QUANTITY, SHELF_LIFE_UNIT_OF_MEASURE_CODE,
            SAMPLE_INDICATOR, COMPETITOR_INDICATOR, GENERIC_INDICATOR,
            PRESCRIPTION_REQUIRED_INDICATOR, ATC_CODE, WHO_CODE, NFC_CODE,
            CHC_NEC_CODE, USC_CODE, MANUFACTURER_ID, MANUFACTURER, CORPORATION,
            DAILY_DOSAGE_QUANTITY, IS_IMPORTED, GENERIC_PRODUCT_DESCRIPTION,
            CHANNEL, CHC_FLAG, START_DATETIME, END_DATETIME
        )
        SELECT
            sat.IDENTIFIER_MD5, sat.RECORD_MD5, sat.LOAD_DATETIME, sat.ETL_BATCH_ID, sat.RECORD_SOURCE,
            sat.GEOGRAPHIC_ID, sat.DATASET_ID, sat.SOURCE_DATASET_ID, sat.DATASET_PRODUCT_ID,
            sat.PRODUCT_TYPE_CODE, sat.PRODUCT_NAME, sat.STANDARDIZED_PRODUCT_NAME, sat.DESCRIPTION,
            sat.PRODUCT_STATUS_CODE, sat.EFFECTIVE_DATE, sat.END_DATE, sat.BRAND_NAME, sat.GENERIC_NAMES,
            sat.APPROVED_DATE, sat.MARKETING_START_DATE, sat.MARKETING_END_DATE, sat.EXPIRATION_DATE,
            sat.SUBSTANCE, sat.DOSE_FORM_CODE, sat.STRENGTH, sat.ROUTE_OF_ADMINISTRATION_CODE,
            sat.PHARMACEUTICAL_PRODUCT_QUANTITY, sat.UNIT_OF_PRESENTATION_CODE,
            sat.PRIMARY_PACKAGE_QUANTITY, sat.PRIMARY_PACKAGE_TYPE_CODE,
            sat.SECONDARY_PACKAGE_QUANTITY, sat.SECONDARY_PACKAGE_TYPE_CODE,
            sat.PACKAGE_QUANTITY, sat.SHELF_LIFE_QUANTITY, sat.SHELF_LIFE_UNIT_OF_MEASURE_CODE,
            sat.SAMPLE_INDICATOR, sat.COMPETITOR_INDICATOR, sat.GENERIC_INDICATOR,
            sat.PRESCRIPTION_REQUIRED_INDICATOR, sat.ATC_CODE, sat.WHO_CODE, sat.NFC_CODE,
            sat.CHC_NEC_CODE, sat.USC_CODE, sat.MANUFACTURER_ID, sat.MANUFACTURER, sat.CORPORATION,
            sat.DAILY_DOSAGE_QUANTITY, sat.IS_IMPORTED, sat.GENERIC_PRODUCT_DESCRIPTION,
            sat.CHANNEL, sat.CHC_FLAG,
            sat.START_DATETIME,
            CURRENT_TIMESTAMP()
        FROM {{ sat_table }} sat
        INNER JOIN {{ filtered_stg }} stg
            ON stg.IDENTIFIER_MD5 = sat.IDENTIFIER_MD5
        WHERE sat.END_DATETIME IS NULL
          AND stg.RECORD_MD5 != sat.RECORD_MD5
    {% endset %}
 
    {# ------------------------------------------------------------------
       STEP 3: Remove the outdated active SAT record.
       After archiving to HIST (step 2), delete the old version from
       SAT_PRODUCT_FILE so it can be replaced by the new version.
       Only deletes where identifier_md5 matches and record_md5 differs.
    ------------------------------------------------------------------ #}
    {% set delete_changed_sat_sql %}
        DELETE FROM {{ sat_table }} sat
        USING {{ filtered_stg }} stg
        WHERE stg.IDENTIFIER_MD5 = sat.IDENTIFIER_MD5
          AND sat.END_DATETIME IS NULL
          AND stg.RECORD_MD5 != sat.RECORD_MD5
    {% endset %}
 
    {# ------------------------------------------------------------------
       STEP 4: Insert the new version of changed records into SAT.
       For records whose identifier_md5 exists in HUB but no longer have
       an active SAT row (deleted in step 3), insert the updated staging
       data with a fresh START_DATETIME.
    ------------------------------------------------------------------ #}
    {% set insert_changed_sat_sql %}
        INSERT INTO {{ sat_table }} (
            IDENTIFIER_MD5, RECORD_MD5, LOAD_DATETIME, ETL_BATCH_ID, RECORD_SOURCE,
            GEOGRAPHIC_ID, DATASET_ID, SOURCE_DATASET_ID, DATASET_PRODUCT_ID,
            PRODUCT_TYPE_CODE, PRODUCT_NAME, STANDARDIZED_PRODUCT_NAME, DESCRIPTION,
            PRODUCT_STATUS_CODE, EFFECTIVE_DATE, END_DATE, BRAND_NAME, GENERIC_NAMES,
            APPROVED_DATE, MARKETING_START_DATE, MARKETING_END_DATE, EXPIRATION_DATE,
            SUBSTANCE, DOSE_FORM_CODE, STRENGTH, ROUTE_OF_ADMINISTRATION_CODE,
            PHARMACEUTICAL_PRODUCT_QUANTITY, UNIT_OF_PRESENTATION_CODE,
            PRIMARY_PACKAGE_QUANTITY, PRIMARY_PACKAGE_TYPE_CODE,
            SECONDARY_PACKAGE_QUANTITY, SECONDARY_PACKAGE_TYPE_CODE,
            PACKAGE_QUANTITY, SHELF_LIFE_QUANTITY, SHELF_LIFE_UNIT_OF_MEASURE_CODE,
            SAMPLE_INDICATOR, COMPETITOR_INDICATOR, GENERIC_INDICATOR,
            PRESCRIPTION_REQUIRED_INDICATOR, ATC_CODE, WHO_CODE, NFC_CODE,
            CHC_NEC_CODE, USC_CODE, MANUFACTURER_ID, MANUFACTURER, CORPORATION,
            DAILY_DOSAGE_QUANTITY, IS_IMPORTED, GENERIC_PRODUCT_DESCRIPTION,
            CHANNEL, CHC_FLAG, START_DATETIME
        )
        SELECT
            stg.IDENTIFIER_MD5, stg.RECORD_MD5, CURRENT_TIMESTAMP(), TO_VARCHAR(DATE_PART(EPOCH_SECOND, CURRENT_TIMESTAMP())), 'VEEVA_CRM',
            stg.GEOGRAPHIC_ID, stg.DATASET_ID, stg.SOURCE_DATASET_ID, stg.DATASET_PRODUCT_ID,
            stg.PRODUCT_TYPE_CODE, stg.PRODUCT_NAME, stg.STANDARDIZED_PRODUCT_NAME, stg.DESCRIPTION,
            stg.PRODUCT_STATUS_CODE, stg.EFFECTIVE_DATE, stg.END_DATE, stg.BRAND_NAME, stg.GENERIC_NAMES,
            stg.APPROVED_DATE, stg.MARKETING_START_DATE, stg.MARKETING_END_DATE, stg.EXPIRATION_DATE,
            stg.SUBSTANCE, stg.DOSE_FORM_CODE, stg.STRENGTH, stg.ROUTE_OF_ADMINISTRATION_CODE,
            stg.PHARMACEUTICAL_PRODUCT_QUANTITY, stg.UNIT_OF_PRESENTATION_CODE,
            stg.PRIMARY_PACKAGE_QUANTITY, stg.PRIMARY_PACKAGE_TYPE_CODE,
            stg.SECONDARY_PACKAGE_QUANTITY, stg.SECONDARY_PACKAGE_TYPE_CODE,
            stg.PACKAGE_QUANTITY, stg.SHELF_LIFE_QUANTITY, stg.SHELF_LIFE_UNIT_OF_MEASURE_CODE,
            stg.SAMPLE_INDICATOR, stg.COMPETITOR_INDICATOR, stg.GENERIC_INDICATOR,
            stg.PRESCRIPTION_REQUIRED_INDICATOR, stg.ATC_CODE, stg.WHO_CODE, stg.NFC_CODE,
            stg.CHC_NEC_CODE, stg.USC_CODE, stg.MANUFACTURER_ID, stg.MANUFACTURER, stg.CORPORATION,
            stg.DAILY_DOSAGE_QUANTITY, stg.IS_IMPORTED, stg.GENERIC_PRODUCT_DESCRIPTION,
            stg.CHANNEL, stg.CHC_FLAG,
            CURRENT_TIMESTAMP()
        FROM {{ filtered_stg }} stg
        INNER JOIN {{ hub_table }} hub
            ON stg.IDENTIFIER_MD5 = hub.IDENTIFIER_MD5
        WHERE NOT EXISTS (
              SELECT 1 FROM {{ sat_table }} s
              WHERE s.IDENTIFIER_MD5 = stg.IDENTIFIER_MD5
                AND s.END_DATETIME IS NULL
          )
    {% endset %}
 
    {# ------------------------------------------------------------------
       STEP 5: Insert brand-new records into the HUB.
       Records from the delta staging table whose identifier_md5 does not
       exist in HUB_PRODUCT_FILE at all are completely new products.
       Insert them with BUSINESS_KEY (composite of geographic_id, dataset_id,
       source_dataset_id, dataset_product_id) and LOAD_DATETIME.
    ------------------------------------------------------------------ #}
    {% set insert_new_hub_sql %}
        INSERT INTO {{ hub_table }} (
            IDENTIFIER_MD5, BUSINESS_KEY, LOAD_DATETIME, RECORD_SOURCE, ETL_BATCH_ID
        )
        SELECT
            stg.IDENTIFIER_MD5,
            CONCAT_WS('||', stg.GEOGRAPHIC_ID, stg.DATASET_ID, stg.SOURCE_DATASET_ID, stg.DATASET_PRODUCT_ID),
            CURRENT_TIMESTAMP(),
            'VEEVA_CRM',
            TO_VARCHAR(DATE_PART(EPOCH_SECOND, CURRENT_TIMESTAMP()))
        FROM {{ filtered_stg }} stg
        WHERE NOT EXISTS (
              SELECT 1 FROM {{ hub_table }} hub
              WHERE hub.IDENTIFIER_MD5 = stg.IDENTIFIER_MD5
          )
    {% endset %}
 
    {# ------------------------------------------------------------------
       STEP 6: Insert brand-new records into the SAT.
       Companion to step 5 -- for every new HUB entry, also create the
       corresponding SAT_PRODUCT_FILE row with all product attributes
       and START_DATETIME set to now.
    ------------------------------------------------------------------ #}
    {% set insert_new_sat_sql %}
        INSERT INTO {{ sat_table }} (
            IDENTIFIER_MD5, RECORD_MD5, LOAD_DATETIME, ETL_BATCH_ID, RECORD_SOURCE,
            GEOGRAPHIC_ID, DATASET_ID, SOURCE_DATASET_ID, DATASET_PRODUCT_ID,
            PRODUCT_TYPE_CODE, PRODUCT_NAME, STANDARDIZED_PRODUCT_NAME, DESCRIPTION,
            PRODUCT_STATUS_CODE, EFFECTIVE_DATE, END_DATE, BRAND_NAME, GENERIC_NAMES,
            APPROVED_DATE, MARKETING_START_DATE, MARKETING_END_DATE, EXPIRATION_DATE,
            SUBSTANCE, DOSE_FORM_CODE, STRENGTH, ROUTE_OF_ADMINISTRATION_CODE,
            PHARMACEUTICAL_PRODUCT_QUANTITY, UNIT_OF_PRESENTATION_CODE,
            PRIMARY_PACKAGE_QUANTITY, PRIMARY_PACKAGE_TYPE_CODE,
            SECONDARY_PACKAGE_QUANTITY, SECONDARY_PACKAGE_TYPE_CODE,
            PACKAGE_QUANTITY, SHELF_LIFE_QUANTITY, SHELF_LIFE_UNIT_OF_MEASURE_CODE,
            SAMPLE_INDICATOR, COMPETITOR_INDICATOR, GENERIC_INDICATOR,
            PRESCRIPTION_REQUIRED_INDICATOR, ATC_CODE, WHO_CODE, NFC_CODE,
            CHC_NEC_CODE, USC_CODE, MANUFACTURER_ID, MANUFACTURER, CORPORATION,
            DAILY_DOSAGE_QUANTITY, IS_IMPORTED, GENERIC_PRODUCT_DESCRIPTION,
            CHANNEL, CHC_FLAG, START_DATETIME
        )
        SELECT
            stg.IDENTIFIER_MD5, stg.RECORD_MD5, CURRENT_TIMESTAMP(), TO_VARCHAR(DATE_PART(EPOCH_SECOND, CURRENT_TIMESTAMP())), 'VEEVA_CRM',
            stg.GEOGRAPHIC_ID, stg.DATASET_ID, stg.SOURCE_DATASET_ID, stg.DATASET_PRODUCT_ID,
            stg.PRODUCT_TYPE_CODE, stg.PRODUCT_NAME, stg.STANDARDIZED_PRODUCT_NAME, stg.DESCRIPTION,
            stg.PRODUCT_STATUS_CODE, stg.EFFECTIVE_DATE, stg.END_DATE, stg.BRAND_NAME, stg.GENERIC_NAMES,
            stg.APPROVED_DATE, stg.MARKETING_START_DATE, stg.MARKETING_END_DATE, stg.EXPIRATION_DATE,
            stg.SUBSTANCE, stg.DOSE_FORM_CODE, stg.STRENGTH, stg.ROUTE_OF_ADMINISTRATION_CODE,
            stg.PHARMACEUTICAL_PRODUCT_QUANTITY, stg.UNIT_OF_PRESENTATION_CODE,
            stg.PRIMARY_PACKAGE_QUANTITY, stg.PRIMARY_PACKAGE_TYPE_CODE,
            stg.SECONDARY_PACKAGE_QUANTITY, stg.SECONDARY_PACKAGE_TYPE_CODE,
            stg.PACKAGE_QUANTITY, stg.SHELF_LIFE_QUANTITY, stg.SHELF_LIFE_UNIT_OF_MEASURE_CODE,
            stg.SAMPLE_INDICATOR, stg.COMPETITOR_INDICATOR, stg.GENERIC_INDICATOR,
            stg.PRESCRIPTION_REQUIRED_INDICATOR, stg.ATC_CODE, stg.WHO_CODE, stg.NFC_CODE,
            stg.CHC_NEC_CODE, stg.USC_CODE, stg.MANUFACTURER_ID, stg.MANUFACTURER, stg.CORPORATION,
            stg.DAILY_DOSAGE_QUANTITY, stg.IS_IMPORTED, stg.GENERIC_PRODUCT_DESCRIPTION,
            stg.CHANNEL, stg.CHC_FLAG,
            CURRENT_TIMESTAMP()
        FROM {{ filtered_stg }} stg
        WHERE NOT EXISTS (
              SELECT 1 FROM {{ hub_table }} hub
              WHERE hub.IDENTIFIER_MD5 = stg.IDENTIFIER_MD5
          )
    {% endset %}
 
    {# ==================== EXECUTION ==================== #}
 
    {# Step 1: Mark unchanged records as still active (touch UPDATED_DATETIME) #}
    {% do log("Step 1: Updating unchanged records (identifier_md5 + record_md5 match) - set updated_datetime", info=True) %}
    {% do run_query(update_unchanged_sql) %}
 
    {# Step 1a: Build temp delta table -- only changed + new records remain #}
    {% do log("Step 1a: Creating filtered staging table - excluding unchanged records already in SAT", info=True) %}
    {% do run_query(create_filtered_stg_sql) %}
 
    {# Step 2: Copy old SAT rows (that are about to change) into HIST with END_DATETIME #}
    {% do log("Step 2: Archiving changed records to SAT_PRODUCT_HIST (identifier_md5 match, record_md5 mismatch)", info=True) %}
    {% do run_query(archive_changed_sql) %}
 
    {# Step 3: Delete the now-archived old SAT rows so we can insert the new version #}
    {% do log("Step 3: Removing old changed records from SAT_PRODUCT_FILE", info=True) %}
    {% do run_query(delete_changed_sat_sql) %}
 
    {# Step 4: Insert the updated version of changed records into SAT #}
    {% do log("Step 4: Inserting updated changed records into SAT_PRODUCT_FILE", info=True) %}
    {% do run_query(insert_changed_sat_sql) %}
 
    {# Step 5: Insert completely new products into HUB (no prior identifier_md5) #}
    {% do log("Step 5: Inserting new records into HUB_PRODUCT_FILE", info=True) %}
    {% do run_query(insert_new_hub_sql) %}
 
    {# Step 6: Insert the SAT row for newly created HUB entries #}
    {% do log("Step 6: Inserting new records into SAT_PRODUCT_FILE", info=True) %}
    {% do run_query(insert_new_sat_sql) %}
 
    {% do log("Delta load completed successfully.", info=True) %}
 
{% endmacro %}