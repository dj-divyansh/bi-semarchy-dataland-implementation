{#
    MACRO: delta_load_product_file_v2_merge
    ============================================================
    Purpose:
        MERGE-based version of delta_load_product_file_v2.
        Performs the same Data Vault 2.0 delta/CDC load for Veeva CRM product data
        but uses MERGE statements to reduce 7 SQL statements down to 4.
 
    Delta Logic Overview (same as original):
        1. UNCHANGED records (identifier_md5 match AND record_md5 match):
           -> Only update UPDATED_DATETIME on the active SAT record.
 
        2. CHANGED records (identifier_md5 match BUT record_md5 mismatch):
           -> Archive the old SAT record to SAT_PRODUCT_HIST with END_DATETIME.
           -> Replace the old SAT record with new version (UPDATE all columns).
 
        3. NEW records (no identifier_md5 match in HUB):
           -> Insert into HUB_PRODUCT_FILE with LOAD_DATETIME.
           -> Insert into SAT_PRODUCT_FILE with START_DATETIME.
 
    Approach:
        Step 1:  MERGE on SAT - handles UNCHANGED (update timestamp) + builds temp delta
        Step 2:  INSERT into HIST - archive changed records (must precede SAT merge for changed)
        Step 3:  MERGE on SAT - handles CHANGED (update all cols) + NEW (insert)
        Step 4:  MERGE on HUB - handles NEW hub records
 
    Tables Involved:
        - Source: stg_veeva_crm_product_all_v2 (dbt staging view)
        - Hub:    DEV_DFHPMS2EU_DB.DW_DFHPMS2EU_SEMARCHY_SCHEMA.HUB_PRODUCT_FILE
        - Sat:    DEV_DFHPMS2EU_DB.DW_DFHPMS2EU_SEMARCHY_SCHEMA.SAT_PRODUCT_FILE
        - Hist:   DEV_DFHPMS2EU_DB.DW_DFHPMS2EU_SEMARCHY_SCHEMA.SAT_PRODUCT_HIST
 
    Usage:
        dbt run-operation delta_load_product_file_v2_merge
#}
{% macro delta_load_product_file_v2_merge(stg_table_override=None, skip_reject_filter=false) %}
 
    {% set etl_batch_id = env_var('ETL_BATCH_ID', env_var('DBT_JOB_RUN_ID', invocation_id)) %}
    {% set hub_table = ref('HUB_PRODUCT_FILE') %}
    {% set sat_table = ref('SAT_PRODUCT_FILE') %}
    {% set hist_table = ref('SAT_PRODUCT_HIST') %}
    {% if stg_table_override is not none and (stg_table_override | trim) != '' %}
        {% set stg_table = stg_table_override %}
    {% else %}
        {% set stg_table = ref('STG_PRODUCT_VEEVA') %}
    {% endif %}
    {% set reject_table = ref('REJECT') %}

    {% if stg_table_override is not none and (stg_table_override | trim) != '' %}
        {% set sat_desc = run_query("DESC TABLE " ~ sat_table) %}
        {% for row in sat_desc.rows %}
            {% set col_name = row[0] %}
            {% set col_type = row[1] %}
            {% if 'VARCHAR' in col_type or 'TEXT' in col_type %}
                {% do run_query("ALTER TABLE " ~ sat_table ~ " ALTER COLUMN \"" ~ col_name ~ "\" SET DATA TYPE VARCHAR") %}
            {% endif %}
        {% endfor %}
    {% endif %}

    {% set tmp_dq_table = sat_table.database ~ '.' ~ sat_table.schema ~ '.TMP_STG_PRODUCT_DQ' %}
    {% set tmp_delta_table = sat_table.database ~ '.' ~ sat_table.schema ~ '.TMP_STG_PRODUCT_DELTA' %}
    {% set tmp_delta_counts_table = sat_table.database ~ '.' ~ sat_table.schema ~ '.TMP_PRODUCT_DELTA_COUNTS' %}
    {% set dq_stg = tmp_dq_table %}
    {% set filtered_stg = tmp_delta_table %}

    {% set audit_db = target.database %}
    {% set audit_schema = 'DW_DFHPMS2EU_SEMARCHY_SCHEMA' %}
    {% set audit_process_log = audit_db ~ '.' ~ audit_schema ~ '.AUDIT_PROCESS_LOG' %}
    {% set audit_model_name = 'delta_load_product_file_v2_merge' %}

    {% set audit_start_sql %}
        MERGE INTO {{ audit_process_log }} tgt
        USING (
            SELECT
                '{{ etl_batch_id }}' AS ETL_BATCH_ID,
                'delta' AS LAYER_NAME,
                '{{ audit_model_name }}' AS MODEL_NAME,
                'RUNNING' AS PROCESS_STATUS,
                CURRENT_TIMESTAMP() AS START_TIMESTAMP,
                NULL::TIMESTAMP_LTZ AS END_TIMESTAMP,
                0::NUMBER AS ROWS_PROCESSED,
                ''::VARCHAR AS ERROR_MESSAGE,
                0::NUMBER AS DELTA_INSERTED_ROWS,
                0::NUMBER AS DELTA_UPDATED_ROWS
        ) src
        ON tgt.ETL_BATCH_ID = src.ETL_BATCH_ID
           AND tgt.MODEL_NAME = src.MODEL_NAME
        WHEN MATCHED THEN
            UPDATE SET
                LAYER_NAME = src.LAYER_NAME,
                PROCESS_STATUS = 'RUNNING',
                START_TIMESTAMP = COALESCE(tgt.START_TIMESTAMP, src.START_TIMESTAMP),
                END_TIMESTAMP = NULL,
                ROWS_PROCESSED = src.ROWS_PROCESSED,
                ERROR_MESSAGE = src.ERROR_MESSAGE,
                DELTA_INSERTED_ROWS = src.DELTA_INSERTED_ROWS,
                DELTA_UPDATED_ROWS = src.DELTA_UPDATED_ROWS
        WHEN NOT MATCHED THEN
            INSERT (ETL_BATCH_ID, LAYER_NAME, MODEL_NAME, PROCESS_STATUS, START_TIMESTAMP, END_TIMESTAMP, ROWS_PROCESSED, ERROR_MESSAGE, DELTA_INSERTED_ROWS, DELTA_UPDATED_ROWS)
            VALUES (src.ETL_BATCH_ID, src.LAYER_NAME, src.MODEL_NAME, src.PROCESS_STATUS, src.START_TIMESTAMP, src.END_TIMESTAMP, src.ROWS_PROCESSED, src.ERROR_MESSAGE, src.DELTA_INSERTED_ROWS, src.DELTA_UPDATED_ROWS);
    {% endset %}

    {% set audit_success_sql %}
        UPDATE {{ audit_process_log }}
        SET
            PROCESS_STATUS = 'SUCCESS',
            END_TIMESTAMP = CURRENT_TIMESTAMP(),
            ROWS_PROCESSED = (
                SELECT (DELTA_INSERTED_ROWS + DELTA_UPDATED_ROWS)::NUMBER
                FROM {{ tmp_delta_counts_table }}
            ),
            ERROR_MESSAGE = '',
            DELTA_INSERTED_ROWS = (SELECT DELTA_INSERTED_ROWS FROM {{ tmp_delta_counts_table }}),
            DELTA_UPDATED_ROWS = (SELECT DELTA_UPDATED_ROWS FROM {{ tmp_delta_counts_table }})
        WHERE ETL_BATCH_ID = '{{ etl_batch_id }}'
          AND MODEL_NAME = '{{ audit_model_name }}'
          AND PROCESS_STATUS = 'RUNNING';
    {% endset %}

    {% set create_dq_stg_sql %}
        CREATE OR REPLACE TEMPORARY TABLE {{ dq_stg }} AS
        SELECT stg.*
        FROM {{ stg_table }} stg
        WHERE stg.GEOGRAPHIC_ID IS NOT NULL AND TRIM(stg.GEOGRAPHIC_ID) != ''
          AND stg.PRODUCT_NAME IS NOT NULL AND TRIM(stg.PRODUCT_NAME) != ''
          AND stg.DATASET_PRODUCT_ID IS NOT NULL AND TRIM(stg.DATASET_PRODUCT_ID) != ''
          {% if not skip_reject_filter %}
          AND NOT EXISTS (
              SELECT 1
              FROM {{ reject_table }} r
              WHERE upper(trim(stg.dataset_product_id)) = r.DATASET_PRODUCT_ID
          )
          {% endif %}
          {% if stg_table_override is not none and (stg_table_override | trim) != '' %}
          QUALIFY ROW_NUMBER() OVER (PARTITION BY stg.IDENTIFIER_MD5 ORDER BY stg.RECORD_MD5 DESC) = 1
          {% endif %}
    {% endset %}
 
    {# ------------------------------------------------------------------
       STEP 1: MERGE on SAT for UNCHANGED records.
       Updates UPDATED_DATETIME where both identifier_md5 and record_md5
       match (no data change). Also creates filtered delta temp table
       for subsequent steps (excluding unchanged records).
    ------------------------------------------------------------------ #}
    {% set merge_unchanged_sat_sql %}
        MERGE INTO {{ sat_table }} sat
        USING {{ dq_stg }} stg
            ON sat.IDENTIFIER_MD5 = stg.IDENTIFIER_MD5
           AND sat.RECORD_MD5 = stg.RECORD_MD5
           AND sat.END_DATETIME IS NULL
        WHEN MATCHED THEN
            UPDATE SET sat.UPDATED_DATETIME = CURRENT_TIMESTAMP()
    {% endset %}
 
    {% set create_filtered_stg_sql %}
        CREATE OR REPLACE TEMPORARY TABLE {{ filtered_stg }} AS
        SELECT stg.*
        FROM {{ dq_stg }} stg
        WHERE NOT EXISTS (
              SELECT 1
              FROM {{ sat_table }} sat
              WHERE sat.IDENTIFIER_MD5 = stg.IDENTIFIER_MD5
                AND sat.RECORD_MD5 = stg.RECORD_MD5
                AND sat.END_DATETIME IS NULL
          )
    {% endset %}
 
    {# ------------------------------------------------------------------
       STEP 2: Archive changed records to SAT_PRODUCT_HIST.
       Must run BEFORE the SAT merge for changed records so we capture
       the old version before it gets overwritten.
    ------------------------------------------------------------------ #}
    {% set archive_changed_sql %}
        INSERT INTO {{ hist_table }}
        SELECT
            sat.* EXCLUDE (END_DATETIME),
            CURRENT_TIMESTAMP() AS END_DATETIME
        FROM {{ sat_table }} sat
        INNER JOIN {{ filtered_stg }} stg
            ON stg.IDENTIFIER_MD5 = sat.IDENTIFIER_MD5
        WHERE sat.END_DATETIME IS NULL
          AND stg.RECORD_MD5 != sat.RECORD_MD5
          AND NOT EXISTS (
              SELECT 1
              FROM {{ hist_table }} h
              WHERE h.RECORD_MD5 = sat.RECORD_MD5
          )
    {% endset %}
 
    {# ------------------------------------------------------------------
       STEP 3: MERGE on SAT for CHANGED + NEW records.
       - WHEN MATCHED (changed): UPDATE all columns with new staging data,
         reset START_DATETIME (equivalent to original delete + insert).
       - WHEN NOT MATCHED (new): inserts the SAT row after HUB is upserted.
    ------------------------------------------------------------------ #}
    {% set merge_sat_sql %}
        MERGE INTO {{ sat_table }} sat
        USING {{ filtered_stg }} stg
            ON sat.IDENTIFIER_MD5 = stg.IDENTIFIER_MD5
           AND sat.END_DATETIME IS NULL
        WHEN MATCHED AND stg.RECORD_MD5 != sat.RECORD_MD5 THEN
            UPDATE SET
                sat.RECORD_MD5 = stg.RECORD_MD5,
                sat.LOAD_DATETIME = CURRENT_TIMESTAMP(),
                sat.ETL_BATCH_ID = '{{ etl_batch_id }}',
                sat.RECORD_SOURCE = 'VEEVA_CRM',
                sat.GEOGRAPHIC_ID = stg.GEOGRAPHIC_ID,
                sat.DATASET_ID = stg.DATASET_ID,
                sat.SOURCE_DATASET_ID = stg.SOURCE_DATASET_ID,
                sat.DATASET_PRODUCT_ID = stg.DATASET_PRODUCT_ID,
                sat.PRODUCT_TYPE_CODE = stg.PRODUCT_TYPE_CODE,
                sat.PRODUCT_NAME = stg.PRODUCT_NAME,
                sat.STANDARDIZED_PRODUCT_NAME = stg.STANDARDIZED_PRODUCT_NAME,
                sat.DESCRIPTION = stg.DESCRIPTION,
                sat.PRODUCT_STATUS_CODE = stg.PRODUCT_STATUS_CODE,
                sat.EFFECTIVE_DATE = stg.EFFECTIVE_DATE,
                sat.END_DATE = stg.END_DATE,
                sat.BRAND_NAME = stg.BRAND_NAME,
                sat.GENERIC_NAMES = stg.GENERIC_NAMES,
                sat.APPROVED_DATE = stg.APPROVED_DATE,
                sat.MARKETING_START_DATE = stg.MARKETING_START_DATE,
                sat.MARKETING_END_DATE = stg.MARKETING_END_DATE,
                sat.EXPIRATION_DATE = stg.EXPIRATION_DATE,
                sat.SUBSTANCE = stg.SUBSTANCE,
                sat.DOSE_FORM_CODE = stg.DOSE_FORM_CODE,
                sat.STRENGTH = stg.STRENGTH,
                sat.ROUTE_OF_ADMINISTRATION_CODE = stg.ROUTE_OF_ADMINISTRATION_CODE,
                sat.PHARMACEUTICAL_PRODUCT_QUANTITY = stg.PHARMACEUTICAL_PRODUCT_QUANTITY,
                sat.UNIT_OF_PRESENTATION_CODE = stg.UNIT_OF_PRESENTATION_CODE,
                sat.PRIMARY_PACKAGE_QUANTITY = stg.PRIMARY_PACKAGE_QUANTITY,
                sat.PRIMARY_PACKAGE_TYPE_CODE = stg.PRIMARY_PACKAGE_TYPE_CODE,
                sat.SECONDARY_PACKAGE_QUANTITY = stg.SECONDARY_PACKAGE_QUANTITY,
                sat.SECONDARY_PACKAGE_TYPE_CODE = stg.SECONDARY_PACKAGE_TYPE_CODE,
                sat.PACKAGE_QUANTITY = stg.PACKAGE_QUANTITY,
                sat.SHELF_LIFE_QUANTITY = stg.SHELF_LIFE_QUANTITY,
                sat.SHELF_LIFE_UNIT_OF_MEASURE_CODE = stg.SHELF_LIFE_UNIT_OF_MEASURE_CODE,
                sat.SAMPLE_INDICATOR = stg.SAMPLE_INDICATOR,
                sat.COMPETITOR_INDICATOR = stg.COMPETITOR_INDICATOR,
                sat.GENERIC_INDICATOR = stg.GENERIC_INDICATOR,
                sat.PRESCRIPTION_REQUIRED_INDICATOR = stg.PRESCRIPTION_REQUIRED_INDICATOR,
                sat.ATC_CODE = stg.ATC_CODE,
                sat.WHO_CODE = stg.WHO_CODE,
                sat.NFC_CODE = stg.NFC_CODE,
                sat.CHC_NEC_CODE = stg.CHC_NEC_CODE,
                sat.USC_CODE = stg.USC_CODE,
                sat.MANUFACTURER_ID = stg.MANUFACTURER_ID,
                sat.MANUFACTURER = stg.MANUFACTURER,
                sat.CORPORATION = stg.CORPORATION,
                sat.DAILY_DOSAGE_QUANTITY = stg.DAILY_DOSAGE_QUANTITY,
                sat.IS_IMPORTED = stg.IS_IMPORTED,
                sat.GENERIC_PRODUCT_DESCRIPTION = stg.GENERIC_PRODUCT_DESCRIPTION,
                sat.CHANNEL = stg.CHANNEL,
                sat.CHC_FLAG = stg.CHC_FLAG,
                sat.START_DATETIME = CURRENT_TIMESTAMP(),
                sat.END_DATETIME = NULL,
                sat.UPDATED_DATETIME = CURRENT_TIMESTAMP()
        WHEN NOT MATCHED THEN
            INSERT (
                IDENTIFIER_MD5, RECORD_MD5, START_DATETIME, UPDATED_DATETIME, ETL_BATCH_ID, RECORD_SOURCE,
                GEOGRAPHIC_ID, DATASET_ID, SOURCE_DATASET_ID, DATASET_PRODUCT_ID,
                PRODUCT_TYPE_CODE, PRODUCT_NAME, STANDARDIZED_PRODUCT_NAME, DESCRIPTION,
                PRODUCT_STATUS_CODE, EFFECTIVE_DATE, END_DATE, BRAND_NAME, GENERIC_NAMES,
                APPROVED_DATE, MARKETING_START_DATE, MARKETING_END_DATE, EXPIRATION_DATE,
                SUBSTANCE, DOSE_FORM_CODE, STRENGTH, ROUTE_OF_ADMINISTRATION_CODE,
                PHARMACEUTICAL_PRODUCT_QUANTITY, UNIT_OF_PRESENTATION_CODE,
                PRIMARY_PACKAGE_QUANTITY, PRIMARY_PACKAGE_TYPE_CODE,
                SECONDARY_PACKAGE_QUANTITY, SECONDARY_PACKAGE_TYPE_CODE,
                PACKAGE_QUANTITY, SHELF_LIFE_QUANTITY, SHELF_LIFE_UNIT_OF_MEASURE_CODE,
                SAMPLE_INDICATOR, COMPETITOR_INDICATOR, GENERIC_INDICATOR,
                PRESCRIPTION_REQUIRED_INDICATOR, ATC_CODE, WHO_CODE, NFC_CODE,
                CHC_NEC_CODE, USC_CODE, MANUFACTURER_ID, MANUFACTURER, CORPORATION,
                DAILY_DOSAGE_QUANTITY, IS_IMPORTED, GENERIC_PRODUCT_DESCRIPTION,
                CHANNEL, CHC_FLAG
            )
            VALUES (
                stg.IDENTIFIER_MD5,
                stg.RECORD_MD5,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                '{{ etl_batch_id }}',
                'VEEVA_CRM',
                stg.GEOGRAPHIC_ID, stg.DATASET_ID, stg.SOURCE_DATASET_ID, stg.DATASET_PRODUCT_ID,
                stg.PRODUCT_TYPE_CODE, stg.PRODUCT_NAME, stg.STANDARDIZED_PRODUCT_NAME, stg.DESCRIPTION,
                stg.PRODUCT_STATUS_CODE, stg.EFFECTIVE_DATE, stg.END_DATE, stg.BRAND_NAME, stg.GENERIC_NAMES,
                stg.APPROVED_DATE, stg.MARKETING_START_DATE, stg.MARKETING_END_DATE, stg.EXPIRATION_DATE,
                stg.SUBSTANCE, stg.DOSE_FORM_CODE, stg.STRENGTH, stg.ROUTE_OF_ADMINISTRATION_CODE,
                stg.PHARMACEUTICAL_PRODUCT_QUANTITY, stg.UNIT_OF_PRESENTATION_CODE,
                stg.PRIMARY_PACKAGE_QUANTITY, stg.PRIMARY_PACKAGE_TYPE_CODE,
                stg.SECONDARY_PACKAGE_QUANTITY, stg.SECONDARY_PACKAGE_TYPE_CODE,
                stg.PACKAGE_QUANTITY, stg.SHELF_LIFE_QUANTITY, stg.SHELF_LIFE_UNIT_OF_MEASURE_CODE,
                stg.SAMPLE_INDICATOR, stg.COMPETITOR_INDICATOR, stg.GENERIC_INDICATOR,
                stg.PRESCRIPTION_REQUIRED_INDICATOR, stg.ATC_CODE, stg.WHO_CODE, stg.NFC_CODE,
                stg.CHC_NEC_CODE, stg.USC_CODE, stg.MANUFACTURER_ID, stg.MANUFACTURER, stg.CORPORATION,
                stg.DAILY_DOSAGE_QUANTITY, stg.IS_IMPORTED, stg.GENERIC_PRODUCT_DESCRIPTION,
                stg.CHANNEL, stg.CHC_FLAG
            )
    {% endset %}
 
    {# ------------------------------------------------------------------
       STEP 4: MERGE on HUB for NEW records.
       Inserts into HUB only when identifier_md5 does not already exist.
    ------------------------------------------------------------------ #}
    {% set merge_hub_sql %}
        MERGE INTO {{ hub_table }} hub
        USING (
            SELECT DISTINCT
                stg.IDENTIFIER_MD5,
                stg.DATASET_PRODUCT_ID
            FROM {{ filtered_stg }} stg
        ) stg
            ON hub.IDENTIFIER_MD5 = stg.IDENTIFIER_MD5
        WHEN NOT MATCHED THEN
            INSERT (IDENTIFIER_MD5, BUSINESS_KEY, START_DATETIME, LOAD_DATETIME, RECORD_SOURCE, ETL_BATCH_ID)
            VALUES (
                stg.IDENTIFIER_MD5,
                stg.DATASET_PRODUCT_ID,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                'VEEVA_CRM',
                '{{ etl_batch_id }}'
            )
    {% endset %}

    {% set create_delta_counts_sql %}
        CREATE OR REPLACE TEMPORARY TABLE {{ tmp_delta_counts_table }} AS
        SELECT
            (
                SELECT COUNT(*)
                FROM {{ filtered_stg }} stg
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM {{ hub_table }} hub
                    WHERE hub.IDENTIFIER_MD5 = stg.IDENTIFIER_MD5
                )
            )::NUMBER AS DELTA_INSERTED_ROWS,
            (
                SELECT COUNT(*)
                FROM {{ sat_table }} sat
                INNER JOIN {{ filtered_stg }} stg
                    ON stg.IDENTIFIER_MD5 = sat.IDENTIFIER_MD5
                WHERE sat.END_DATETIME IS NULL
                  AND stg.RECORD_MD5 != sat.RECORD_MD5
            )::NUMBER AS DELTA_UPDATED_ROWS
    {% endset %}
 
    {# ==================== EXECUTION ==================== #}
 
    {% do ensure_audit_tables() %}
    {% do run_query(audit_start_sql) %}

    {% do log("Step 0: Creating DQ-passed staging table", info=True) %}
    {% do run_query(create_dq_stg_sql) %}

    {% do log("Step 1: MERGE - updating unchanged records (identifier_md5 + record_md5 match) - set updated_datetime", info=True) %}
    {% do run_query(merge_unchanged_sat_sql) %}
 
    {% do log("Step 1a: Creating filtered staging table - excluding unchanged records", info=True) %}
    {% do run_query(create_filtered_stg_sql) %}
    {% do run_query(create_delta_counts_sql) %}
 
    {% do log("Step 2: MERGE on HUB - inserting new hub records", info=True) %}
    {% do run_query(merge_hub_sql) %}

    {% do log("Step 3: Archiving changed records to SAT_PRODUCT_HIST", info=True) %}
    {% do run_query(archive_changed_sql) %}

    {% do log("Step 4: MERGE on SAT - updating changed records + inserting new records", info=True) %}
    {% do run_query(merge_sat_sql) %}

    {% do run_query(audit_success_sql) %}
 
    {% do log("Delta load (MERGE version) completed successfully.", info=True) %}
 
{% endmacro %}
