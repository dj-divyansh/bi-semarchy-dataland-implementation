{#
    MACRO: delta_load_product_file_v2
    ============================================================
    Purpose:
        Performs a Data Vault 2.0 delta/CDC load for Veeva CRM product data.
        Reads from the cleaned staging view (CLEAN_STG_PRODUCT_VEEVA) and applies
        changes to the HUB, SAT, and HIST tables using MD5 hash comparison.
 
    Delta Logic Overview:
        1. UNCHANGED records (identifier_md5 match AND record_md5 match):
           -> Only update UPDATED_DATETIME on the active SAT record.
           -> Then exclude these from further processing via a temp delta table.
 
        2. CHANGED records (identifier_md5 match BUT record_md5 mismatch):
           -> Archive the old SAT record to SAT_PRODUCT_HIST with END_DATETIME.
           -> Delete the old record from SAT_PRODUCT_FILE.
           -> Insert the new version into SAT_PRODUCT_FILE with START_DATETIME.
 
        3. NEW records (no identifier_md5 match in HUB):
           -> Insert into HUB_PRODUCT_FILE with LOAD_DATETIME.
           -> Insert into SAT_PRODUCT_FILE with START_DATETIME.
 
    Filtering:
        Records with NULL or empty GEOGRAPHIC_ID, PRODUCT_NAME, or
        DATASET_PRODUCT_ID are excluded from all processing.
 
    Tables Involved:
        - Source: CLEAN_STG_PRODUCT_VEEVA (dbt view)
        - Hub:    HUB_PRODUCT_FILE
        - Sat:    SAT_PRODUCT_FILE
        - Hist:   SAT_PRODUCT_HIST
 
    Usage:
        dbt run-operation delta_load_product_file_v2
#}
{% macro delta_load_product_file_v2() %}
 
    {# -- Target table references -- #}
    {% set etl_batch_id = env_var('ETL_BATCH_ID', env_var('DBT_JOB_RUN_ID', invocation_id)) %}
    {% set hub_table = ref('HUB_PRODUCT_FILE') %}
    {% set sat_table = ref('SAT_PRODUCT_FILE') %}
    {% set hist_table = ref('SAT_PRODUCT_HIST') %}
    {% set stg_table = ref('STG_PRODUCT_VEEVA') %}
    {% set reject_table = ref('REJECT') %}
 
    {% set default_record_source_max_len = 255 %}
    {% set sat_record_source_max_len = default_record_source_max_len %}
    {% set hub_record_source_max_len = default_record_source_max_len %}
    {% if execute %}
        {% set sat_rs_len_sql %}
            SELECT CHARACTER_MAXIMUM_LENGTH
            FROM {{ sat_table.database }}.INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = '{{ sat_table.schema }}'
              AND TABLE_NAME = '{{ sat_table.identifier }}'
              AND COLUMN_NAME = 'RECORD_SOURCE'
            LIMIT 1
        {% endset %}
        {% set sat_rs_len_res = run_query(sat_rs_len_sql) %}
        {% if sat_rs_len_res is not none and (sat_rs_len_res.rows | length) > 0 and sat_rs_len_res.rows[0][0] is not none %}
            {% set sat_record_source_max_len = sat_rs_len_res.rows[0][0] %}
        {% endif %}

        {% set hub_rs_len_sql %}
            SELECT CHARACTER_MAXIMUM_LENGTH
            FROM {{ hub_table.database }}.INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = '{{ hub_table.schema }}'
              AND TABLE_NAME = '{{ hub_table.identifier }}'
              AND COLUMN_NAME = 'RECORD_SOURCE'
            LIMIT 1
        {% endset %}
        {% set hub_rs_len_res = run_query(hub_rs_len_sql) %}
        {% if hub_rs_len_res is not none and (hub_rs_len_res.rows | length) > 0 and hub_rs_len_res.rows[0][0] is not none %}
            {% set hub_record_source_max_len = hub_rs_len_res.rows[0][0] %}
        {% endif %}
    {% endif %}
    {% set tmp_dq_table = sat_table.database ~ '.' ~ sat_table.schema ~ '.TMP_STG_PRODUCT_DQ' %}
    {% set tmp_delta_table = sat_table.database ~ '.' ~ sat_table.schema ~ '.TMP_STG_PRODUCT_DELTA' %}
    {% set tmp_delta_counts_table = sat_table.database ~ '.' ~ sat_table.schema ~ '.TMP_PRODUCT_DELTA_COUNTS' %}
    {% set dq_stg = tmp_dq_table %}
    {% set filtered_stg = tmp_delta_table %}
    {% set audit_db = target.database %}
    {% set audit_schema = 'DW_DFHPMS2EU_SEMARCHY_SCHEMA' %}
    {% set audit_process_log = audit_db ~ '.' ~ audit_schema ~ '.AUDIT_PROCESS_LOG' %}
    {% set audit_model_name = 'delta_load_product_file_v2' %}
 
    {# ------------------------------------------------------------------
       STEP 0: Build a filtered staging table (DQ-passed only).
       Apply the data quality filter once and reuse it across steps.
    ------------------------------------------------------------------ #}
    {% set create_dq_stg_sql %}
        CREATE OR REPLACE TEMPORARY TABLE {{ dq_stg }} AS
        SELECT stg.*
        FROM {{ stg_table }} stg
        LEFT JOIN {{ reject_table }} r
            ON upper(trim(stg.dataset_product_id)) = r.DATASET_PRODUCT_ID
        WHERE stg.GEOGRAPHIC_ID IS NOT NULL AND TRIM(stg.GEOGRAPHIC_ID) != ''
          AND stg.PRODUCT_NAME IS NOT NULL AND TRIM(stg.PRODUCT_NAME) != ''
          AND stg.DATASET_PRODUCT_ID IS NOT NULL AND TRIM(stg.DATASET_PRODUCT_ID) != ''
          AND r.DATASET_PRODUCT_ID IS NULL
    {% endset %}
 
    {# ------------------------------------------------------------------
       STEP 1a: Build a filtered delta staging table.
       Excludes records where BOTH identifier_md5 and record_md5 already
       match an active SAT row (i.e. unchanged records). Also applies
       the data quality filter (non-null geographic_id, product_name,
       dataset_product_id). The resulting temp table is used by all
       subsequent steps so they only process true deltas.
    ------------------------------------------------------------------ #}
    {% set create_filtered_stg_sql %}
        CREATE OR REPLACE TEMPORARY TABLE {{ filtered_stg }} AS
        SELECT stg.*
        FROM {{ dq_stg }} stg
        WHERE NOT EXISTS (
              SELECT 1
              FROM {{ sat_table }} sat
              WHERE sat.IDENTIFIER_MD5 = stg.IDENTIFIER_MD5
                AND sat.RECORD_MD5 = stg.RECORD_MD5
          )
    {% endset %}
 
    {# ------------------------------------------------------------------
       STEP 1: Touch unchanged records.
       When both identifier_md5 AND record_md5 match between staging and
       the active SAT row, the data has not changed. We only refresh
       UPDATED_DATETIME to record that the source still provides this
       record. No new SAT row is created.
    ------------------------------------------------------------------ #}
    {% set update_unchanged_sql %}
        UPDATE {{ sat_table }} sat
        SET sat.UPDATED_DATETIME = CURRENT_TIMESTAMP()
        FROM {{ dq_stg }} stg
        WHERE stg.IDENTIFIER_MD5 = sat.IDENTIFIER_MD5
          AND stg.RECORD_MD5 = sat.RECORD_MD5
    {% endset %}
 
    {# ------------------------------------------------------------------
       STEP 2: Archive changed records to history.
       When identifier_md5 matches (same business key) but record_md5
       differs (attributes changed), copy the old active SAT row into
       SAT_PRODUCT_HIST and stamp END_DATETIME = now. This preserves
       the previous version of the record for audit/history.
    ------------------------------------------------------------------ #}
    {% set archive_changed_sql %}
        INSERT INTO {{ hist_table }}
        SELECT
            sat.* EXCLUDE (END_DATETIME),
            CURRENT_TIMESTAMP() AS END_DATETIME
        FROM {{ sat_table }} sat
        INNER JOIN {{ filtered_stg }} stg
            ON stg.IDENTIFIER_MD5 = sat.IDENTIFIER_MD5
        WHERE stg.RECORD_MD5 != sat.RECORD_MD5
          AND NOT EXISTS (
              SELECT 1
              FROM {{ hist_table }} h
              WHERE h.RECORD_MD5 = sat.RECORD_MD5
          )
    {% endset %}
 
    {# ------------------------------------------------------------------
       STEP 3: Remove the outdated active SAT record.
       After archiving to HIST (step 2), delete the old version from
       SAT_PRODUCT_FILE so it can be replaced by the new version.
       Only deletes where identifier_md5 matches and record_md5 differs.
    ------------------------------------------------------------------ #}
    {% set delete_changed_sat_sql %}
        DELETE FROM {{ sat_table }} sat
        USING {{ filtered_stg }} stg
        WHERE stg.IDENTIFIER_MD5 = sat.IDENTIFIER_MD5
          AND stg.RECORD_MD5 != sat.RECORD_MD5
    {% endset %}
 
    {# ------------------------------------------------------------------
       STEP 4: Insert the new version of changed records into SAT.
       For records whose identifier_md5 exists in HUB but no longer have
       an active SAT row (deleted in step 3), insert the updated staging
       data with a fresh START_DATETIME.
    ------------------------------------------------------------------ #}
    {% set insert_missing_sat_sql %}
        INSERT INTO {{ sat_table }} (
            IDENTIFIER_MD5,
            RECORD_MD5,
            START_DATETIME,
            UPDATED_DATETIME,
            ETL_BATCH_ID,
            RECORD_SOURCE,
            GEOGRAPHIC_ID, DATASET_ID, SOURCE_DATASET_ID, DATASET_PRODUCT_ID, PRODUCT_TYPE_CODE,
            PRODUCT_NAME, STANDARDIZED_PRODUCT_NAME, DESCRIPTION, PRODUCT_STATUS_CODE, EFFECTIVE_DATE,
            END_DATE, BRAND_NAME, GENERIC_NAMES, APPROVED_DATE, MARKETING_START_DATE,
            MARKETING_END_DATE, EXPIRATION_DATE, SUBSTANCE, DOSE_FORM_CODE, STRENGTH,
            ROUTE_OF_ADMINISTRATION_CODE, PHARMACEUTICAL_PRODUCT_QUANTITY, UNIT_OF_PRESENTATION_CODE, PRIMARY_PACKAGE_QUANTITY, PRIMARY_PACKAGE_TYPE_CODE,
            SECONDARY_PACKAGE_QUANTITY, SECONDARY_PACKAGE_TYPE_CODE, PACKAGE_QUANTITY, SHELF_LIFE_QUANTITY, SHELF_LIFE_UNIT_OF_MEASURE_CODE,
            SAMPLE_INDICATOR, COMPETITOR_INDICATOR, GENERIC_INDICATOR, PRESCRIPTION_REQUIRED_INDICATOR, ATC_CODE,
            WHO_CODE, NFC_CODE, CHC_NEC_CODE, USC_CODE, MANUFACTURER_ID,
            MANUFACTURER, CORPORATION, DAILY_DOSAGE_QUANTITY, IS_IMPORTED, GENERIC_PRODUCT_DESCRIPTION,
            CHANNEL, CHC_FLAG
        )
        SELECT
            stg.IDENTIFIER_MD5,
            stg.RECORD_MD5,
            CURRENT_TIMESTAMP(),
            CURRENT_TIMESTAMP(),
            '{{ etl_batch_id }}',
            LEFT('VEEVA_CRM', {{ sat_record_source_max_len }}),
            stg.GEOGRAPHIC_ID, stg.DATASET_ID, stg.SOURCE_DATASET_ID, stg.DATASET_PRODUCT_ID, stg.PRODUCT_TYPE_CODE,
            stg.PRODUCT_NAME, stg.STANDARDIZED_PRODUCT_NAME, stg.DESCRIPTION, stg.PRODUCT_STATUS_CODE, stg.EFFECTIVE_DATE,
            stg.END_DATE, stg.BRAND_NAME, stg.GENERIC_NAMES, stg.APPROVED_DATE, stg.MARKETING_START_DATE,
            stg.MARKETING_END_DATE, stg.EXPIRATION_DATE, stg.SUBSTANCE, stg.DOSE_FORM_CODE, stg.STRENGTH,
            stg.ROUTE_OF_ADMINISTRATION_CODE, stg.PHARMACEUTICAL_PRODUCT_QUANTITY, stg.UNIT_OF_PRESENTATION_CODE, stg.PRIMARY_PACKAGE_QUANTITY, stg.PRIMARY_PACKAGE_TYPE_CODE,
            stg.SECONDARY_PACKAGE_QUANTITY, stg.SECONDARY_PACKAGE_TYPE_CODE, stg.PACKAGE_QUANTITY, stg.SHELF_LIFE_QUANTITY, stg.SHELF_LIFE_UNIT_OF_MEASURE_CODE,
            stg.SAMPLE_INDICATOR, stg.COMPETITOR_INDICATOR, stg.GENERIC_INDICATOR, stg.PRESCRIPTION_REQUIRED_INDICATOR, stg.ATC_CODE,
            stg.WHO_CODE, stg.NFC_CODE, stg.CHC_NEC_CODE, stg.USC_CODE, stg.MANUFACTURER_ID,
            stg.MANUFACTURER, stg.CORPORATION, stg.DAILY_DOSAGE_QUANTITY, stg.IS_IMPORTED, stg.GENERIC_PRODUCT_DESCRIPTION,
            stg.CHANNEL, stg.CHC_FLAG
        FROM {{ filtered_stg }} stg
        WHERE EXISTS (
                SELECT 1
                FROM {{ hub_table }} hub
                WHERE hub.IDENTIFIER_MD5 = stg.IDENTIFIER_MD5
          )
          AND NOT EXISTS (
                SELECT 1
                FROM {{ sat_table }} s
                WHERE s.IDENTIFIER_MD5 = stg.IDENTIFIER_MD5
          )
    {% endset %}
 
    {# ------------------------------------------------------------------
       STEP 5: Insert brand-new records into the HUB.
       Records from the delta staging table whose identifier_md5 does not
       exist in HUB_PRODUCT_FILE at all are completely new products.
       Insert them with BUSINESS_KEY (composite of geographic_id, dataset_id,
       source_dataset_id, dataset_product_id) and LOAD_DATETIME.
    ------------------------------------------------------------------ #}
    {% set insert_new_hub_sql %}
        INSERT INTO {{ hub_table }} (
            IDENTIFIER_MD5, START_DATETIME, RECORD_SOURCE, ETL_BATCH_ID, ORIGIN_STG
        )
        SELECT
            stg.IDENTIFIER_MD5,
            CURRENT_TIMESTAMP(),
            LEFT('VEEVA_CRM', {{ hub_record_source_max_len }}),
            '{{ etl_batch_id }}',
            'PRODUCT'
        FROM {{ filtered_stg }} stg
        WHERE NOT EXISTS (
              SELECT 1 FROM {{ hub_table }} hub
              WHERE hub.IDENTIFIER_MD5 = stg.IDENTIFIER_MD5
          )
    {% endset %}

    {% set audit_start_sql %}
        MERGE INTO {{ audit_process_log }} tgt
        USING (
            SELECT
                '{{ etl_batch_id }}' AS ETL_BATCH_ID,
                'delta' AS LAYER_NAME,
                '{{ audit_model_name }}' AS MODEL_NAME,
                'RUNNING' AS PROCESS_STATUS,
                CURRENT_TIMESTAMP() AS START_TIMESTAMP,
                NULL::TIMESTAMP_LTZ AS END_TIMESTAMP,
                0::NUMBER AS ROWS_PROCESSED,
                ''::VARCHAR AS ERROR_MESSAGE,
                0::NUMBER AS DELTA_INSERTED_ROWS,
                0::NUMBER AS DELTA_UPDATED_ROWS
        ) src
        ON tgt.ETL_BATCH_ID = src.ETL_BATCH_ID
           AND tgt.MODEL_NAME = src.MODEL_NAME
        WHEN MATCHED THEN
            UPDATE SET
                LAYER_NAME = src.LAYER_NAME,
                PROCESS_STATUS = 'RUNNING',
                START_TIMESTAMP = COALESCE(tgt.START_TIMESTAMP, src.START_TIMESTAMP),
                END_TIMESTAMP = NULL,
                ROWS_PROCESSED = src.ROWS_PROCESSED,
                ERROR_MESSAGE = src.ERROR_MESSAGE,
                DELTA_INSERTED_ROWS = src.DELTA_INSERTED_ROWS,
                DELTA_UPDATED_ROWS = src.DELTA_UPDATED_ROWS
        WHEN NOT MATCHED THEN
            INSERT (ETL_BATCH_ID, LAYER_NAME, MODEL_NAME, PROCESS_STATUS, START_TIMESTAMP, END_TIMESTAMP, ROWS_PROCESSED, ERROR_MESSAGE, DELTA_INSERTED_ROWS, DELTA_UPDATED_ROWS)
            VALUES (src.ETL_BATCH_ID, src.LAYER_NAME, src.MODEL_NAME, src.PROCESS_STATUS, src.START_TIMESTAMP, src.END_TIMESTAMP, src.ROWS_PROCESSED, src.ERROR_MESSAGE, src.DELTA_INSERTED_ROWS, src.DELTA_UPDATED_ROWS);
    {% endset %}

    {% set create_delta_counts_sql %}
        CREATE OR REPLACE TEMPORARY TABLE {{ tmp_delta_counts_table }} AS
        SELECT
            (
                SELECT COUNT(DISTINCT stg.IDENTIFIER_MD5)
                FROM {{ filtered_stg }} stg
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM {{ hub_table }} hub
                    WHERE hub.IDENTIFIER_MD5 = stg.IDENTIFIER_MD5
                )
            )::NUMBER AS DELTA_INSERTED_ROWS,
            (
                SELECT COUNT(DISTINCT sat.IDENTIFIER_MD5)
                FROM {{ sat_table }} sat
                INNER JOIN {{ filtered_stg }} stg
                    ON stg.IDENTIFIER_MD5 = sat.IDENTIFIER_MD5
                WHERE stg.RECORD_MD5 != sat.RECORD_MD5
            )::NUMBER AS DELTA_UPDATED_ROWS
    {% endset %}

    {% set audit_success_sql %}
        UPDATE {{ audit_process_log }}
        SET
            PROCESS_STATUS = 'SUCCESS',
            END_TIMESTAMP = CURRENT_TIMESTAMP(),
            ROWS_PROCESSED = (
                SELECT (DELTA_INSERTED_ROWS + DELTA_UPDATED_ROWS)::NUMBER
                FROM {{ tmp_delta_counts_table }}
            ),
            ERROR_MESSAGE = '',
            DELTA_INSERTED_ROWS = (SELECT DELTA_INSERTED_ROWS FROM {{ tmp_delta_counts_table }}),
            DELTA_UPDATED_ROWS = (SELECT DELTA_UPDATED_ROWS FROM {{ tmp_delta_counts_table }})
        WHERE ETL_BATCH_ID = '{{ etl_batch_id }}'
          AND MODEL_NAME = '{{ audit_model_name }}'
          AND PROCESS_STATUS = 'RUNNING';
    {% endset %}
 
    {# ==================== EXECUTION ==================== #}

    {% do ensure_audit_tables() %}
    {% do run_query(audit_start_sql) %}
 
    {# Step 0: Create DQ-passed staging table #}
    {% do log("Step 0: Creating DQ-passed staging table", info=True) %}
    {% do run_query(create_dq_stg_sql) %}
 
    {# Step 1: Mark unchanged records as still active (touch UPDATED_DATETIME) #}
    {% do log("Step 1: Updating unchanged records (identifier_md5 + record_md5 match) - set updated_datetime", info=True) %}
    {% do run_query(update_unchanged_sql) %}
 
    {# Step 1a: Build temp delta table -- only changed + new records remain #}
    {% do log("Step 1a: Creating delta table - excluding unchanged records already in SAT", info=True) %}
    {% do run_query(create_filtered_stg_sql) %}
    {% do run_query(create_delta_counts_sql) %}
 
    {# Step 2: Copy old SAT rows (that are about to change) into HIST with END_DATETIME #}
    {% do log("Step 2: Archiving changed records to SAT_PRODUCT_HIST (identifier_md5 match, record_md5 mismatch)", info=True) %}
    {% do run_query(archive_changed_sql) %}
 
    {# Step 3: Delete the now-archived old SAT rows so we can insert the new version #}
    {% do log("Step 3: Removing old changed records from SAT_PRODUCT_FILE", info=True) %}
    {% do run_query(delete_changed_sat_sql) %}
 
    {# Step 4: Insert completely new products into HUB (no prior identifier_md5) #}
    {% do log("Step 4: Inserting new records into HUB_PRODUCT_FILE", info=True) %}
    {% do run_query(insert_new_hub_sql) %}
 
    {# Step 5: Insert missing SAT rows (changed + new) #}
    {% do log("Step 5: Inserting missing records into SAT_PRODUCT_FILE", info=True) %}
    {% do run_query(insert_missing_sat_sql) %}
 
    {% do run_query(audit_success_sql) %}
    {% do log("Delta load completed successfully.", info=True) %}
 
{% endmacro %}
